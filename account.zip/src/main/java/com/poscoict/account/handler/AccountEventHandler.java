package com.poscoict.account.handler;

import com.poscoict.account.event.AccountRegisteredEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
public class AccountEventHandler {

    //두개 EventListener 가 있으면 어떤게 먼저 실행될지 모르기 때문에 Order라는 어노테이션을 통해 순서 지정
    @Order(value = Ordered.HIGHEST_PRECEDENCE)
    @EventListener
    public void on(AccountRegisteredEvent event){
        System.out.println("Account EventHandler on");
        //여기서 읽기전용 데이터를 만들고 저장 할수 있다.
    }

    @Order(value = Ordered.HIGHEST_PRECEDENCE + 1)
    @EventListener
    public void on2(AccountRegisteredEvent event){
        System.out.println("Account EventHandler on2");
        //여기서 읽기전용 데이터를 만들고 저장 할수 있다.
    }
}
