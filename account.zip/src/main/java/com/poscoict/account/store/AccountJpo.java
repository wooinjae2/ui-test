package com.poscoict.account.store;


import com.poscoict.account.domain.Account;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="TB_ACNT")
@Getter
@Setter
@NoArgsConstructor
public class AccountJpo {

    @Id
    private String id;
    private String email;
    @Column(name="NM")
    private String name;
    @Column(name="YR")
    private int year;
    @Column(name="MTH")
    private int month;
    @Column(name="DY")
    private int day;

    public AccountJpo(Account account){
        this.id = account.getAccountId();
        this.name = account.getName();
        this.email = account.getEmail();
        this.year = account.getBirthday().getYear();
        this.month = account.getBirthday().getMonth();
        this.day = account.getBirthday().getDay();
    }

    public Account toDomain(){
        return new Account(this.id, this.email, this.name, new Account.Birthday(this.year, this.month, this.day));
    }
}
