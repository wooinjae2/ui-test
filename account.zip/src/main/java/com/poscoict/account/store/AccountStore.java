package com.poscoict.account.store;

import com.poscoict.account.AccountJpo;
import com.poscoict.account.AccountRepository;
import com.poscoict.account.domain.Account;
import org.springframework.stereotype.Repository;

import java.util.NoSuchElementException;
import java.util.Optional;

@Repository
public class AccountStore {

    private final AccountRepository accountRepository; //spring bean이니까 final로

    public AccountStore(AccountRepository accountRepository){
        this.accountRepository = accountRepository;
    }
    public void createAccount(Account account){
        AccountJpo jpo = new AccountJpo(account);
        this.accountRepository.save(jpo);
    }

    public Account retrieveAccount(String accountId){
        Optional<AccountJpo> accountJpo = this.accountRepository.findById(accountId);
        //select 결과가 없으면 Optional이라는 클래스로 감싸서 리턴한다
        //java8부터 써드파티 라이브러리 optional을 기본으로 제공했고
        if(! accountJpo.isPresent()){
            throw new NoSuchElementException(String.format("Account($s) is not found", accountId));
        } // 결과가 있으면
        return accountJpo.get().toDomain();

    }

}
