package com.poscoict.account.store;

import com.poscoict.account.store.AccountJpo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AccountRepository extends JpaRepository<AccountJpo, String> {
  List<AccountJpo> findAllByYear(int year);
  List<AccountJpo> findAllByYearAndMonth(int year, int month);
}
