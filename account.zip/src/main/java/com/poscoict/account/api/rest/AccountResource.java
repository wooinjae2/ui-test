package com.poscoict.account.api.rest;

import com.poscoict.account.AccountService;
import com.poscoict.account.RegisterAccountCommand;
import com.poscoict.account.domain.Account;
import org.springframework.web.bind.annotation.*;

@RestController
public class AccountResource {

    private final AccountService accountService; //생성하고 안바뀌니까 final로

    public AccountResource(AccountService accountService){ //spring에서 권고하는 방식
        this.accountService = accountService;
    }

    @PostMapping
    public String registerAccount(@RequestBody RegisterAccountCommand command){
        //파라미터를 email name 받아도 상관 없지만 메소드에 변화가 있을때마다 트리를 다 따라가면서 바꿔줘야 하는데
        //Command객체로 묶어주면 객체만 바꿔주면 된다.
        return this.accountService.registerAccount(command);
    }

    @GetMapping(value="/{accountId}")
    public Account findAccount(@PathVariable String accountId){
        return accountService.findAccount(accountId);
    }
}
