package com.poscoict.account.api.rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//
@RestController
public class GreetingResource {

    //파라미터 받는방법 2가지  http://localhost:8080/poscoict 경로방식 (@GetMapping(value = "/{name}/{no}")) @PathVariable
    //http://localhost:8080/?name=poscoict&address=asd query string 방식 @RequestParam
    //사용 기준 PathVariable Entity하나 또는 Aggregate하나 를 조회할때 사용 한다 장비의 1번 장비의2번 등등
    //필터링 할때? a조건이 & 뭐일때
    @GetMapping(value = "/{name}/{no}")
    public String greet(@PathVariable String name, @PathVariable int no){
        return "Hello " + name + "("+no + ")";
    }

}
