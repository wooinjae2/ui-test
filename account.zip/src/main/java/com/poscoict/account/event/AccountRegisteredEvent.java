package com.poscoict.account.event;

import com.poscoict.account.domain.Account;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AccountRegisteredEvent {
    private String accountId;
    private Account.Birthday birthday;
    //등록된 회원중에 1-12월 분포를 보고싶다. 바차트를 그릴때 굳이 그룹바이 할필요 없이 이 데이터로 바로 사용 가능

}
