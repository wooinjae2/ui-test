package com.poscoict.account.domain;

import lombok.AllArgsConstructor;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


//gradle이 빌드할때 메소드를 자동으로 만들어 준다.
//Domain객체
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Account {
    private String accountId; //PK 자동으로 생성된다.
    private String email;
    private String name;
    private Birthday birthday;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Birthday {
        private int year;
        private int month;
        private int day;
    }

}
