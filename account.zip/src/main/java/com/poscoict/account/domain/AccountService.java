package com.poscoict.account.domain;

import com.poscoict.account.domain.Account;
import com.poscoict.account.event.AccountRegisteredEvent;
import com.poscoict.account.store.AccountStore;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.util.UUID;

//RestApi를 받아서 Account객체에 세팅하고 DB에 저장을 할것이다.
@Service
public class AccountService {

    private AccountStore accountStore;
    private ApplicationEventPublisher eventPublisher;

    public AccountService(AccountStore accountStore, ApplicationEventPublisher eventPublisher) {
        this.accountStore = accountStore;
        this.eventPublisher = eventPublisher;
    }

    public String registerAccount(RegisterAccountCommand command){
        //command를 붙여야 하나
        //
        String newAccountId = UUID.randomUUID().toString();
        Account account = new Account();
        account.setAccountId(newAccountId);
        account.setEmail(command.getEmail());
        account.setName(command.getName());
        account.setBirthday(command.getBirthday());

        //Insert 새로생성된걸로 다음 작업을 해야 한다면 id리턴 아니면 리턴void
        accountStore.createAccount(account);
        this.eventPublisher.publishEvent(new AccountRegisteredEvent(account.getAccountId(), account.getBirthday()));
        //Update delete insert 한다 ?
        System.out.println("AccountService.registeredAccount()");//실행은동기식으로 된다.
        return newAccountId;
    }

    public Account findAccount(String accountId){
        return this.accountStore.retrieveAccount(accountId);
    }
}
